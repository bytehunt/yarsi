<h3 align="center">
	<img src="https://0x0.st/oFrC.png" widht=300px height=250px alt="yarsi"/><br/>
	<img src="https://raw.githubusercontent.com/catppuccin/catppuccin/main/assets/misc/transparent.png" height="30" width="0px"/>
	Yarsi:&nbsp;Yet another rust sys info fetcher ✨ </a>
	<img src="https://raw.githubusercontent.com/catppuccin/catppuccin/main/assets/misc/transparent.png" height="30" width="0px"/>
</h3>

<p align="center">
	<a href="https://github.com/BinaryBrainiacs/BinaryBrainiacs/blob/main/LICENSE"><img src="https://img.shields.io/static/v1.svg?style=for-the-badge&label=License&message=MIT&logoColor=d9e0ee&colorA=363a4f&colorB=b7bdf8"/></a>
	<a href="https://github.com/BinaryBrainiacs/yarsi/stargazers"><img src="https://img.shields.io/github/stars/BinaryBrainiacs/yarsi?colorA=363a4f&colorB=b7bdf8&style=for-the-badge"></a>
	<a href="https://github.com/BinaryBrainiacs/yarsi/issues"><img src="https://img.shields.io/github/issues/BinaryBrainiacs/yarsi?colorA=363a4f&colorB=f5a97f&style=for-the-badge"></a>
</p>


## requirements 🙀

- cargo 🦀
   install with 
 ```
$ curl https://sh.rustup.rs -sSf | sh
 ```
 
## installation ❤️‍🩹

```
$ cargo install --git https://github.com/BinaryBrainiacs/yarsi
```

<p align="center">
	Copyright &copy; 2023 <a href="https://github.com/BinaryBrainiacs" target="_blank">BinaryBrainiacs rocks 😎 </a>
</p>

